###########
# generate from templates
python -m post.template \
    make-template \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/Templates/f3.1-m2-targeted-boundary-dt.jsonc \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-m2-targeted-boundary-dt.jsonc \
    --map-file $BASE_OUTPUT_DIRECTORY/F3/Templates/map.jsonc
python -m post.sanity_checks \
    sanity \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-m2-targeted-boundary-dt.jsonc

python -m post.template \
    make-template \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/Templates/f3.1-sb-targeted-boundary-dt.jsonc \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-sb-targeted-boundary-dt.jsonc \
    --map-file $BASE_OUTPUT_DIRECTORY/F3/Templates/map.jsonc
python -m post.sanity_checks \
    sanity \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-sb-targeted-boundary-dt.jsonc

python -m post.template \
    make-template \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/Templates/f3.2-m2-targeted-clustering-dt.jsonc \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-m2-targeted-clustering-dt.jsonc \
    --map-file $BASE_OUTPUT_DIRECTORY/F3/Templates/map.jsonc
python -m post.sanity_checks \
    sanity \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-m2-targeted-clustering-dt.jsonc

python -m post.template \
    make-template \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/Templates/f3.2-sb-targeted-clustering-dt.jsonc \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-sb-targeted-clustering-dt.jsonc \
    --map-file $BASE_OUTPUT_DIRECTORY/F3/Templates/map.jsonc
python -m post.sanity_checks \
    sanity \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-sb-targeted-clustering-dt.jsonc

###########
# execute.
python main.py --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-m2-targeted-boundary-dt.jsonc

python main.py --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-sb-targeted-boundary-dt.jsonc

python main.py --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-m2-targeted-clustering-dt.jsonc

python main.py --input-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-sb-targeted-clustering-dt.jsonc


###########
# post-processing

# just extract data from the monolithic model
python -m post.simple \
    --columns-patterns-to-exclude STD Pipe \
    --input-files \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/ModelQuality/mono_oracled_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/ModelQuality/mono_vanilla_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/ModelQuality/mono_oracled_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/ModelQuality/mono_vanilla_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/ModelQuality/mono_oracled_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/ModelQuality/mono_vanilla_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/ModelQuality/mono_oracled_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/ModelQuality/mono_vanilla_quality_test_set_clean.csv \
    --prefix \
        M2_BOUNDARY_ORACLE_ \
        M2_BOUNDARY_VANILLA_ \
        M2_CLUSTERING_ORACLE_ \
        M2_CLUSTERING_VANILLA_ \
        SB_BOUNDARY_ORACLE_ \
        SB_BOUNDARY_VANILLA_ \
        SB_CLUSTERING_ORACLE_ \
        SB_CLUSTERING_VANILLA_ \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/for_paper_mono.csv \
     merge-files-standard


mkdir -p $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional
mkdir -p $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images

#####
# m2-boundary
# compute arbitrary delta_ref
python -m post.plots \
    compute-arbitrary-delta-ref \
    --metrics Accuracy Recall Precision \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional \
    --pre-prefix m2_boundary_dt_test_set_clean \
    --patterns-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-m2-targeted-boundary-dt_post-delta-ref-more.jsonc
# compute integral of those delta_ref
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_delta_ref.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_delta_ref_stat.csv
# transpose delta-ref
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_delta_ref_stat.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_delta_ref_stat_transposed.csv
# compute integral of traditional quality metrics.
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_trad_metric_stat.csv
# transpose integral of traditional quality metrics.
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_trad_metric_stat.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/m2_boundary_dt_test_set_clean_trad_metric_stat_transposed.csv


# q0
python -m post.plots \
    plot-merged-mono \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --prefix m2_boundary_dt_test_set_clean_q0_mono

# q1
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix m2_boundary_dt_test_set_clean_q1_tsusc \
    --columns-patterns-to-exclude GROUND_TRUTH Dist \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_

# q2
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix m2_boundary_dt_test_set_clean_q2_ground_truth_rr \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH Sink" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix  m2_boundary_dt_test_set_clean_q2_ground_truth_sink \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH RR" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_


#####
# sb-boundary
# compute arbitrary delta_ref
python -m post.plots \
    compute-arbitrary-delta-ref \
    --metrics Accuracy Recall Precision \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional \
    --pre-prefix sb_boundary_dt_test_set_clean \
    --patterns-file $BASE_OUTPUT_DIRECTORY/F3/f3.1-sb-targeted-boundary-dt_post-delta-ref-more.jsonc
# compute integral of those delta_ref
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_delta_ref.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_delta_ref_stat.csv
# transpose delta-ref
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_delta_ref_stat.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_delta_ref_stat_transposed.csv
# compute integral of traditional quality metrics.
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_trad_metric_stat.csv
# transpose integral of traditional quality metrics.
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_trad_metric_stat.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Additional/sb_boundary_dt_test_set_clean_trad_metric_stat_transposed.csv

# q0
python -m post.plots \
    plot-merged-mono \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --prefix sb_boundary_dt_test_set_clean_q0_mono

# q1
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix sb_boundary_dt_test_set_clean_q1_tsusc \
    --columns-patterns-to-exclude GROUND_TRUTH Dist \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_

# q2
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix sb_boundary_dt_test_set_clean_q2_ground_truth_rr \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH Sink" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix  sb_boundary_dt_test_set_clean_q2_ground_truth_sink \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH RR" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_

###
# clustering

mkdir -p $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional
mkdir -p $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images

#####
# m2-clustering
# compute arbitrary delta_ref
python -m post.plots \
    compute-arbitrary-delta-ref \
    --metrics Accuracy Recall Precision \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional \
    --pre-prefix m2_clustering_dt_test_set_clean \
    --patterns-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-m2-targeted-clustering-dt_post-delta-ref-more.jsonc
# compute integral of those delta_ref
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_delta_ref.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_delta_ref_stat.csv
# transpose delta-ref
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_delta_ref_stat.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_delta_ref_stat_transposed.csv
# compute integral of traditional quality metrics.
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_trad_metric_stat.csv
# transpose integral of traditional quality metrics.
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_trad_metric_stat.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/m2_clustering_dt_test_set_clean_trad_metric_stat_transposed.csv

# q0
python -m post.plots \
    plot-merged-mono \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --prefix m2_clustering_dt_test_set_clean_q0_mono

# q1
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix m2_clustering_dt_test_set_clean_q1_tsusc \
    --columns-patterns-to-exclude GROUND_TRUTH Dist \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_

# q2
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix m2_clustering_dt_test_set_clean_q2_ground_truth_rr \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH Sink" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix  m2_clustering_dt_test_set_clean_q2_ground_truth_sink \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH RR" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_


#####
# sb-clustering
# compute arbitrary delta_ref
python -m post.plots \
    compute-arbitrary-delta-ref \
    --metrics Accuracy Recall Precision \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional \
    --pre-prefix sb_clustering_dt_test_set_clean \
    --patterns-file $BASE_OUTPUT_DIRECTORY/F3/f3.2-sb-targeted-clustering-dt_post-delta-ref-more.jsonc
# compute integral of those delta_ref
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_delta_ref.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_delta_ref_stat.csv
# transpose delta-ref
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_delta_ref_stat.csv  \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_delta_ref_stat_transposed.csv
# compute integral of traditional quality metrics.
python -m post.plots \
    summary-stat \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_trad_metric_stat.csv
# transpose integral of traditional quality metrics.
python -m post.plots \
    transpose-arbitrary-delta-ref \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_trad_metric_stat.csv \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Additional/sb_clustering_dt_test_set_clean_trad_metric_stat_transposed.csv

# q0
python -m post.plots \
    plot-merged-mono \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --prefix sb_clustering_dt_test_set_clean_q0_mono

# q1
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix sb_clustering_dt_test_set_clean_q1_tsusc \
    --columns-patterns-to-exclude GROUND_TRUTH Dist \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_

# q2
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix sb_clustering_dt_test_set_clean_q2_ground_truth_rr \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH Sink" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix  sb_clustering_dt_test_set_clean_q2_ground_truth_sink \
    --columns-patterns-to-exclude Dist "GROUND_TRUTH RR" TSUSC \
    --mode SAME_N_DIFFERENT_PIPE \
    --input-file \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_vanilla_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_delta_ref_mono_oracle_test_set_clean.csv \
    --input-file-prefix VANILLA_ ORACLE_


# how good is the ground truth?
# m2 - boundary
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --columns-patterns-to-exclude Distance. Neigh.kDist \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix m2_boundary_dt_ground_truth \
    --always-keep-monolithic true \
    --mode SAME_N_DIFFERENT_PIPE
# sb - boundary
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --columns-patterns-to-exclude Distance. Neigh.kDist \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.1/Images \
    --prefix sb_boundary_dt_ground_truth \
    --always-keep-monolithic true \
    --mode SAME_N_DIFFERENT_PIPE
# m2 - clustering
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --columns-patterns-to-exclude Distance. Neigh.kDist \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix m2_clustering_dt_ground_truth \
    --always-keep-monolithic true \
    --mode SAME_N_DIFFERENT_PIPE
# sb - clustering
python -m post.plots \
    plot-merged \
    --metrics Accuracy Recall Precision \
    --columns-patterns-to-exclude Distance. Neigh.kDist \
    --input-file $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --output-dir $BASE_OUTPUT_DIRECTORY/F3/F3.2/Images \
    --prefix sb_clustering_dt_ground_truth \
    --always-keep-monolithic true \
    --mode SAME_N_DIFFERENT_PIPE


# merge the ground-truth related results to have a unique csv file for the paper.
python -m post.simple \
    --columns-patterns-to-exclude Distance. Neigh.kDist Accuracy Precision \
    --input-files \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/M2-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/M2-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.1/Output/SB-Targeted-Boundary-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
        $BASE_OUTPUT_DIRECTORY/F3/F3.2/Output/SB-Targeted-Clustering-DT/Output/Merged/ensemble_quality_test_set_clean.csv \
    --prefix \
        M2_BOUNDARY_ \
        M2_CLUSTERING_ \
        SB_BOUNDARY_ \
        SB_CLUSTERING_ \
    --output-file $BASE_OUTPUT_DIRECTORY/F3/for_paper_ground_truth.csv \
    merge-files-standard
