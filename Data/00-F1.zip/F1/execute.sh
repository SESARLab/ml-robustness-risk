# F1.1
python main.py --input-file $BASE_OUTPUT_DIRECTORY/F1/f1-m2-targeted-boundary.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/F1/f1-m2-targeted-clustering.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/F1/f1-sb-targeted-boundary.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/F1/f1-sb-targeted-clustering.jsonc

mkdir -p $BASE_OUTPUT_DIRECTORY/F1/Additional
mkdir -p $BASE_OUTPUT_DIRECTORY/F1/Images

python -m post.monolithic_models \
    --input-directory $BASE_OUTPUT_DIRECTORY/F1/Output \
    --output-prefix $BASE_OUTPUT_DIRECTORY/F1/Additional/out \
    build-aggregated-deltas

# we remove things related to the training_set_clean
rm $BASE_OUTPUT_DIRECTORY/F1/Additional/out_DELTA_REF_training_set_clean*
rm $BASE_OUTPUT_DIRECTORY/F1/Additional/out_DELTA_SELF_training_set_clean*

# # sb-clustering
# python -m post.monolithic_models --columns-patterns-to-exclude STD # --files-patterns-to-exclude SCLFA M2 AM Boundary 
# --input-directory $BASE_OUTPUT_DIRECTORY/F1/Output --output-prefix $BASE_OUTPUT_DIRECTORY/F1/Images/plot_sb_clustering build-plots --metrics Accuracy Recall Precision

# 
python -m post.monolithic_models \
    --columns-patterns-to-exclude STD \
    --files-patterns-to-exclude training_set_clean \
    --input-directory $BASE_OUTPUT_DIRECTORY/F1/Output \
    --output-prefix $BASE_OUTPUT_DIRECTORY/F1/Images/plot \
    build-plots \
    --metrics Accuracy Recall Precision \
