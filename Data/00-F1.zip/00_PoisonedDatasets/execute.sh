python -m post.split \
    split \
    --input-file $BASE_OUTPUT_DIRECTORY/00_BaseDatasets/musk2.csv \
    --output-file-train $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/musk2_train.csv \
    --output-file-test $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/musk2_test.csv \
    --train-test-split 0.75

python -m post.split \
    describe \
    --input-file-train $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/musk2_train.csv \
    --input-file-test $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/musk2_test.csv

# {
#   "TRAIN": {
#     "LEN": 1525,
#     "N_0": 760,
#     "N_1": 765
#   },
#   "TEST": {
#     "LEN": 509,
#     "N_0": 257,
#     "N_1": 252
#   }
# }

python -m post.split \
    split \
    --input-file $BASE_OUTPUT_DIRECTORY/00_BaseDatasets/spambase.csv \
    --output-file-train $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/spambase_train.csv \
    --output-file-test $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/spambase_test.csv \
    --train-test-split 0.75

python -m post.split \
    describe \
    --input-file-train $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/spambase_train.csv \
    --input-file-test $BASE_OUTPUT_DIRECTORY/00_BaseDatasetsWorking/spambase_test.csv

# {
#   "TRAIN": {
#     "LEN": 2719,
#     "N_0": 1363,
#     "N_1": 1356
#   },
#   "TEST": {
#     "LEN": 907,
#     "N_0": 450,
#     "N_1": 457
#   }
# }

python main.py --input-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/dataset-m2-targeted-boundary.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/dataset-m2-targeted-clustering.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/dataset-sb-targeted-boundary.jsonc
python main.py --input-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/dataset-sb-targeted-clustering.jsonc

python -m post.visual_poisoned \
    embed \
    --method TSNE \
    --config-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/post-dataset-embed-m2.jsonc \
    --output-file-plot $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/Additional/m2.png \
    --output-file-csv $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/Additional/m2.csv

python -m post.visual_poisoned \
    embed \
    --method TSNE \
    --config-file $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/post-dataset-embed-sb.jsonc \
    --output-file-plot $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/Additional/sb.png \
    --output-file-csv $BASE_OUTPUT_DIRECTORY/00_PoisonedDatasets/Additional/sb.csv

